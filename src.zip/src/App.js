
import './App.css';
import { React } from "react";
import NavBar from './components/navBar';
import Footer from './components/footer';
import Catalog from "./pages/catalog";
// import QuantityPicker from './components/quantityPicker';

function App() {
  return (
    <div className="App">
        <h1>Hello from React </h1>
        <NavBar/>
        <Catalog/>
        {/* <QuantityPicker/> */}
        <Footer/>

    </div>
  );
}

export default App;
