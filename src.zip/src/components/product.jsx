import "./product.css";
import QuantityPicker from "./quantityPicker";

function Product(){
    return(
        <div className="product">
            <img src="https://picsum.photos/200/300" width="300px" height="250px" ></img>
        <h5>Product Name</h5>
        <div className="prices">
            <label>Price:</label>
            <label>Total:</label>
        </div>
        <QuantityPicker/>
        </div>
    )
}

export default Product;