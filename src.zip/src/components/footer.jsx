import "./footer.css";

function Footer(){

    return(
        <label> Organika a really really expensive store</label>
    );
}

export default Footer;