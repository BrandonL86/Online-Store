import "./navBar.css";

function NavBar(){
    return(
        <div className="navBar">
            <h1 class="logo">Organika</h1>
            <div className="Menu-Container">
                    <a href="#">House Plants</a>
                    <a href="#">Planters</a>
                    <a href="#">Flowers & Bouquets</a>
                    <a href="#">Plant Care</a>
            </div>
        </div>

    );

}

export default NavBar;