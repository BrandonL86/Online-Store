let catalog = [
    {
        "title":"Moonshine Snake Plant",
        "category": "Low-Light Plants",
        "price": 35.99,
        "image": "somewhere",
        "id":"Lazy"
    },
    {
        "title":"Peperomia Obtipan Green",
        "category": "Low-Light Plants",
        "price": 48.00,
        "image": "somewhere",
        "id":"Lazy" 
    },
    {
        "title":"Stromanthe Triostar",
        "category": "Pet-Friendly",
        "price": 99.99,
        "image": "somewhere",
        "id":"Pet Safe" 
    },
    {
        "title":"Monstera Deliciosa",
        "category": "Large-Plants",
        "price":78.99,
        "image": "somewhere",
        "id":"Biggie-Talls" 
    },
    {
        "title":"Ficus Altissima",
        "category": "Large-Plants",
        "price": 140.99,
        "image": "somewhere",
        "id":"Biggie-Talls" 
    },
    {
        "title":"White-Orchid",
        "category": "Flowers",
        "price": 83.99,
        "image": "somewhere",
        "id":"Expensive-Orchid" 
    },
    {
        "title":"Pink Anthurium",
        "category": "Flowers",
        "price": 79.99,
        "image": "somewhere",
        "id":"Expensive-Anthurium" 
    },
];